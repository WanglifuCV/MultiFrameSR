%% DEBLUR_MMSE - Image deblurring by approximating the MMSE estimate with samples
% |[IMG_DEBLURRED SIGMA_EST] = DEBLUR_MMSE(MRF, Y, K, X_GT, SIGMA_GT[, SIGMA, USE_HEURISTIC, RB, DOPLOT])| will
% use MRF to deblur the corrupted image Y given the blur kernel K. Additive white Gaussian noise is assumed
% on top of the blurred image; the noise standard deviation doesn't have to be provided and can automatically
% be estimated (return value SIGMA_EST).
% This function performs blind denoising (with noise estimation) when K = 1.
% The true deblurred image X_GT and true noise level SIGMA_GT are used to display the PSNR and SSIM
% during deblurring, as well as to compare the estimated noise level with the true one.
% 
% Optional arguments:
% 
%  SIGMA (default: [])           - Provide a noise level to the algorithm (only sigma = [] enables noise estimation).
%  USE_HEURISTIC (default: true) - Binary flag that toggles between a heuristic deblurring strategy (which works
%                                  well in practice), and a conservative strategy (as used in the CVPR'11 paper).
%  RB (default: true)            - Use Rao-Blackwellized MMSE estimator for the deblurred image and
%                                  the noise level (was used for all experiments in the CVPR'11 paper).
%  DOPLOT (default: false)       - Plot progress and/or results during/after deblurring.
%  
% Notes:
% 
%  - This function is not optimized for blind denoising, but should nevertheless
%    give quite good results in terms of image quality and speed.
%  - A relatively large square blur kernel K of uneven size is assumed,
%    ie. DxD pixel with D uneven and D >= 13. Smaller blur kernels are supported,
%    but probably require some additional boundary handling to provide good quality.
% 
% This file is part of the implementation as described in the paper:
% 
%  Uwe Schmidt, Kevin Schelten, Stefan Roth.
%  Bayesian Deblurring with Integrated Noise Estimation.
%  IEEE Conference on Computer Vision and Pattern Recognition (CVPR'11), Colorado Springs, Colorado, June 2011.
% 
% Please cite the paper if you are using this code in your work.
% 
% The code may be used free of charge for non-commercial and
% educational purposes, the only requirement is that this text is
% preserved within the derivative work. For any other purpose you
% must contact the authors for permission. This code may not be
% redistributed without permission from the authors.
%
%  Author:  Uwe Schmidt, Department of Computer Science, TU Darmstadt
%  Contact: uwe.schmidt@gris.tu-darmstadt.de
% 
% Project page:  http://www.gris.tu-darmstadt.de/research/visinf/software/index.en.htm

% Copyright 2011 TU Darmstadt, Darmstadt, Germany.
% $Id: deblur_mmse.m 251 2011-06-06 09:50:52Z uschmidt $

function [img_deblurred sigma_est] = deblur_mmse(mrf, y, k, x_gt, sigma_gt, sigma, use_heuristic, rb, doplot)
  % initialize unset variables, etc.
  if ~isa(mrf, 'pml.distributions.gsm_foe'), error('MRF unsuitable'), end
  if ~exist('sigma','var'), sigma = []; end
  if ~exist('rb','var'), rb = true; end
  if ~exist('doplot', 'var'), doplot = false; end
  do_blind_denoising = numel(k)==1 && k==1;
  mrf.update_filter_matrices = true;
  mrf.conv_method = 'valid';
  
  % pad observed image y to initialize sampler
  % add 9 pixel replicated boundary in case of blind denoising (will be discarded in the end)
  border = 9 * do_blind_denoising;
  % assumes square blur kernel
  sz = size(k,1);
  border = max((sz-1)/2, border);
  if do_blind_denoising, pad_method = 'symmetric'; else, pad_method = 'replicate'; end
  y_padded = padarray(y, [border border], pad_method, 'both');
  mrf.imdims = size(y_padded);
  npixels = prod(mrf.imdims);
  
  % construct sparse blur matrix approximation
  if do_blind_denoising
    K_approx = speye(npixels);
  else
    k_approx = cut_off(k, 0.50);
    K_approx = pml.image_proc.make_imfilter_mat(k_approx, mrf.imdims, 'replicate', 'valid');
  end
  
  % check for noise estimation
  if isempty(sigma)
    do_noise_est = true;  sigma_blur = 5;     sigma_filter = 1;
  else
    do_noise_est = false; sigma_blur = sigma; sigma_filter = sigma; sigma_est = sigma;
  end
  
  nsamplers = 4;  % number of samplers
  
  % initialize samplers with different images (ideally simple deblurred images, not done here)
  x = repmat(y_padded(:), 1, nsamplers);
  % initialize 3 samplers with simple denoised images (arbitrary)
  x(:,1) = reshape(imfilter(y_padded, fspecial('gaussian', 3, sigma_blur)), numel(y_padded), 1);
  x(:,2) = 255*reshape(wiener2(y_padded/255), numel(y_padded), 1);
  x(:,3) = 255*reshape(medfilt2(y_padded/255), numel(y_padded), 1);
  
  % pre-compute some values for the sampling process
  Wt = vertcat(mrf.filter_matrices{1:mrf.nfilters}, speye(npixels));
  KtK_approx = (K_approx'*K_approx) / sigma_filter^2;
  ker_margin = (sz-1)/2;
  y_valid = y_padded(ker_margin+1:end-ker_margin, ker_margin+1:end-ker_margin);
  size_valid = size(y_valid);
  Kty = reshape(conv2(y_valid, k(end:-1:1,end:-1:1)/sigma_filter^2,'full'), npixels, 1);
  
  % start timer
  tic; tstart = cputime;
  
  % either do heuristic (faster) or conservative deblurring (as done for the results in the paper)
  if use_heuristic
    [img_deblurred sigma_est] = heuristic_deblurring(50 + 10*do_blind_denoising, 20 + 10*do_blind_denoising);
  else
    [img_deblurred sigma_est] = conservative_deblurring;
  end
  
  %%===============================================     Deblurring implementations
  
  % ========================================================
  % = Heuristic deblurring (fixed burn-in and #iterations) =
  % ========================================================
  function [img_deblurred sigma_est] = heuristic_deblurring(max_iters, burnin)
    
    % enable parallel computing if available
    if parallel_computing_available
      if matlabpool('size') == 0
        matlabpool open local
      end
      nworkers = matlabpool('size');
      fprintf('Running %d parallel threads.\n', min(nsamplers,nworkers))
    else
      nworkers = 1;
    end
    
    % mrf object doesn't work with parfor loop (for whatever reason)
    mrf = mrf2struct(mrf);
    
    % initialize variables
    if do_noise_est
      s = zeros(1, nsamplers);
      s_mu = zeros(1, nsamplers);
      sigma_est = zeros(1, nsamplers);
    end
    x_mu = zeros(npixels, nsamplers);
    x_deblurred = zeros(npixels, nsamplers);
    
    % (parallel thread) for each sampler
    parfor i = 1:nsamplers
    
      % temporary variables
      x_avg = zeros(npixels,1);
      if do_noise_est, sigma_avg = 0; end
      c_avg = 0;
      
      % loop for fixed number of iterations
      for iter = 1:max_iters
        % sample z, sigma, x
        z = mrf.sample_z(x(:,i));
        if do_noise_est
          [s(i) s_mu(i)] = sample_sigma_deblurring(reshape(x(:,i),mrf.imdims), y_valid, k);
          % blind denoising: exception for sampler that is initialized with the noisy image
          if do_blind_denoising && iter == 1 && i == 4, s(i) = 50; s_mu(i) = s(i); end
          sigma_cur = s(i);
        else
          sigma_cur = sigma;
        end
        [x(:,i), x_mu(:,i)] = sample_x_deblurring(mrf, z, sigma_cur, k, Wt, Kty, size_valid, KtK_approx, do_noise_est, x_avg);
        
        % running average of x and sigma after fixed burn-in phase
        if iter > burnin
          if rb
            x_tmp = x_mu(:,i);
            if do_noise_est, sigma_tmp = s_mu(i); end
          else
            x_tmp = x(:,i);
            if do_noise_est, sigma_tmp = s(i); end
          end
          x_avg = (x_tmp + c_avg * x_avg) / (c_avg + 1);
          if do_noise_est, sigma_avg = (sigma_tmp + c_avg * sigma_avg) / (c_avg + 1); end
          c_avg = c_avg + 1;
        end
        
        % display progress from every sampler
        fprintf('Sampler %d/%d, Iteration %02d/%02d\n', i, nsamplers, iter, max_iters)
      end
      
      % write individual results back to shared variables
      x_deblurred(:,i) = x_avg;
      if do_noise_est, sigma_est(i) = sigma_avg; end
        
    end
    % record elapsed time
    time = toc; cpu_time = cputime-tstart;
    
    % compute final results
    x_final = reshape(mean(x_deblurred,2), mrf.imdims);
    img_deblurred = x_final(border+1:end-border, border+1:end-border);
    if do_noise_est, sigma_est = mean(sigma_est); end
    
    % measure image quality
    psnr = pml.image_proc.psnr(x_gt, img_deblurred);
    ssim = pml.image_proc.ssim_index(x_gt, img_deblurred);
    
    % show results
    fprintf('sigma_est = %.2f, sigma_gt = %.2f :: %d*%d samples, PSNR = %.2fdB, SSIM = %.3f, runtime = %.2fm\n', ...
            sigma_est, sigma_gt, nsamplers, max_iters-burnin, psnr, ssim, time(end)/60)
    if doplot
      figure(1), clf
      plot_images(1, x_gt, sigma_gt, y, k, img_deblurred, sigma_est);
    end
  end
  
  % ===================================================================================
  % = Conservative deblurring ("EPSR" burn-in convergence, "MAPD" stopping criterium) =
  % ===================================================================================
  function [img_deblurred sigma_est] = conservative_deblurring
    
    % settings
    max_iters = ceil(1000 / nsamplers); % #samples / #samplers
    max_burnin_iters = 100;  % only second half will be considered, i.e. throw away 50 at most.
    mean_mapd_threshold = 1; % convergence threshold
    
    % pre-allocate variables
    x_mu = zeros(npixels, nsamplers);
    x_deblurred = zeros(npixels, nsamplers);
    mapd = nan(nsamplers, max_iters);
    if do_noise_est
      s_burnin = zeros(nsamplers, max_burnin_iters);
      s = zeros(nsamplers, max_iters);
      s_mu = zeros(nsamplers, max_iters);
    end
    x_burnin = zeros(npixels, nsamplers, max_burnin_iters);
    estimands = zeros(max_burnin_iters, nsamplers);
    R_hat = zeros(max_burnin_iters, 1);
    
    % variables to measure progress and performance
    ridx = 1+border:mrf.imdims(1)-border; cidx = 1+border:mrf.imdims(2)-border;
    [rs, cs] = ndgrid(ridx, cidx);
    ind_int = sub2ind(mrf.imdims, rs(:), cs(:));
    psnrs = nan(nsamplers+1, max_iters);
    ssims = nan(nsamplers+1, max_iters);
    time = zeros(1, max_iters);
    cpu_time = zeros(1, max_iters);
    
    % initialize some variables
    iter = 0; burnin = true; converged = false; c = 1;
    if doplot, figure(2), clf, figure(1), clf, colormap(gray(256)), end
    
    % loop until convergence or max_iters depleted
    while ~converged
      iter = iter + 1;
      
      % advance all samplers
      for i = 1:nsamplers
        % sample z, sigma, x
        z = mrf.sample_z(x(:,i));
        if do_noise_est
          [s(i,c), s_mu(i,c)] = sample_sigma_deblurring(reshape(x(:,i),mrf.imdims), y_valid, k);
          % blind denoising: exception for sampler that is initialized with the noisy image
          if do_blind_denoising && iter == 1 && i == 4, s(i,c) = 50; s_mu(i,c) = s(i,c); end
          sigma_cur = s(i,c);
        else
          sigma_cur = sigma;
        end
        [x(:,i), x_mu(:,i)] = sample_x_deblurring(mrf, z, sigma_cur, k, Wt, Kty, size_valid, KtK_approx, do_noise_est, x_deblurred(:,i));
        
        % save all samples in the burn-in phase
        if burnin
          if rb, x_burnin(:, i, iter) = x_mu(:,i); else, x_burnin(:, i, iter) = x(:,i); end
          if do_noise_est
            if rb, s_burnin(i, iter) = s_mu(i,c); else, s_burnin(i, iter) = s(i,c); end
          end
          estimands(iter, i) = mrf.energy(x(:,i));
        end
      end
      
      % check for convergence in burn-in phase
      if burnin
        % compute epsr, ignoring first half of samples, show progress
        R_hat(iter) = pml.support.epsr(estimands(ceil(iter/2):iter,:));
        fprintf('\rBurn-in %2d / %2d, R_hat = %.3f', iter, max_burnin_iters, R_hat(iter))
        if doplot
          subplot(211), plot(1:iter, R_hat(1:iter)), title 'R\_hat (estimated potential scale reduction)'
          subplot(212), plot(1:iter, estimands(1:iter,:)), title 'Energies of burn-in samples'
          drawnow
        end
        
        % check for end of burn-in phase
        if (iter >= 10) && ((R_hat(iter) < 1.1) || (iter > max_burnin_iters))
          burnin = false;
          % use second half of burn-in samples
          x_deblurred = mean(x_burnin(:,:,ceil(iter/2):iter),3);
          c = length(ceil(iter/2):iter);
          if do_noise_est
            s_tmp = s_burnin(:,ceil(iter/2):iter);
            if rb, s_mu(:,1:c) = s_tmp; else, s(:,1:c) = s_tmp; end
          end
          
          % show why burn-in phase ended
          if iter > max_burnin_iters
            fprintf(' :: didn''t reach convergence in burn-in phase.\n')
          else
            fprintf(' :: convergence reached.\n')
          end
        end
      
      % after burn-in phase
      else
        % update deblurred images under each sampler (running average)
        if rb, x_tmp = x_mu; else, x_tmp = x; end
        x_deblurred = (x_tmp + c * x_deblurred) / (c + 1);
        
        % combine results from all samplers
        % overall deblurred image as average of all samplers
        x_final = mean(x_deblurred, 2);
        % remove boundary to obtain the part that corresponds to y
        img_deblurred = reshape(x_final(ind_int),size(y));
        % final sigma estimate
        if do_noise_est
          if rb, sigma_est = mean2(s_mu(:,1:c)); else, sigma_est = mean2(s(:,1:c)); end
        end
        
        % compute PSNR, SSIM for the deblurred images under each sampler and the overall result
        psnrs(1:nsamplers,c) = arrayfun(@(i) pml.image_proc.psnr( ...
                                  reshape(x_deblurred(ind_int,i), size(x_gt)), x_gt), 1:nsamplers);
        ssims(1:nsamplers,c) = arrayfun(@(i) pml.image_proc.ssim_index( ...
                                  reshape(x_deblurred(ind_int,i), size(x_gt)), x_gt), 1:nsamplers);
        psnrs(end,c) = pml.image_proc.psnr(img_deblurred, x_gt);
        ssims(end,c) = pml.image_proc.ssim_index(img_deblurred, x_gt);
        time(c) = toc; cpu_time(c) = cputime-tstart;
        
        % check for convergence
        % mean absolute pixel deviation (MAPD) of individual deblurred images from their average
        mapd(:,c) = mean(abs(bsxfun(@minus, x_deblurred, x_final)));
        converged = mean(mapd(:,c)) < mean_mapd_threshold;
        
        % display progress
        fprintf('\rsigma_est = %.2f, sigma_gt = %.2f :: sample %3d / %3d, PSNR = %.2fdB, SSIM = %.3f, avg. MAPD = %7.4f', ...
                sigma_est, sigma_gt, c, max_iters, psnrs(end,c), ssims(end,c), mean(mapd(:,c)))
        if doplot
          plot_images(1, x_gt, sigma_gt, y, k, img_deblurred, sigma_est);
          plot_progress(2, do_noise_est, rb, s, s_mu, c, psnrs, ssims, mapd, time, cpu_time);
          drawnow
        end
        
        if c >= max_iters, fprintf('\n'); warning('Maximum number of iterations exceeded.'); break, end
        c = c + 1;
      end
      
    end
    fprintf('\n')
  end
  
end

%%=====================================================     Deblurring functions

% Sample from the posterior distribution p(x|z,y,K,\sigma)
% The variable names x, z, y, K, k, Q, and sigma are used as described in the paper
% "Xt" denotes "X transposed"
function [x, x_mu] = sample_x_deblurring(this, z, sigma, k, Wt, Kty, size_valid, KtK_approx, do_noise_est, x_mu_init)

  mrf_filter = this.filter;
  imdims = this.imdims;
  npixels = prod(this.imdims);
  nfilters = this.nfilters;
  nexperts = this.nexperts;
  
  if do_noise_est
    KtK_approx = KtK_approx / sigma^2;
    Kty = Kty / sigma^2;
  end
  
  N = 0;
  for i = 1:nfilters
    z{i} = z{i}(:) * this.experts{min(i,nexperts)}.precision;
    N = N + numel(z{i});
  end
  
  z = {z{:}, this.epsilon * ones(npixels, 1)};
  N = N + npixels;
  Z = spdiags(vertcat(z{:}), 0, N, N);
  
  Q_approx = (Wt' * Z * Wt) + KtK_approx;
  Kt_times_noise = conv2(randn(size_valid), k(end:-1:1,end:-1:1)/sigma, 'full');
  W_sqrtZ_r = (Wt' * sqrt(Z) * randn(N,1)) + Kt_times_noise(:);
  
  % do Cholesky decomposition of sparse approximation of precision matrix Q
  [L p s] = chol(Q_approx, 'lower', 'vector'); % Q_approx(s,s) = L*L'
  assert(p == 0, 'Matrix is not positive definite.');
  % use Cholesky factors as preconditioner for PCG, employ @Q_times to multiply with precision matrix Q
  pcgfun = @(b,x0) pcg(@(x) Q_times(reshape(x,imdims), z, mrf_filter, k, sigma, s), b, 1e-6, 250, L, L', x0);
  
  % solve the two linear equations systems
  x_mu = zeros(npixels,1); x_cov = zeros(npixels,1);
  [x_mu(s)  flag1] = pcgfun(Kty(s), x_mu_init);
  [x_cov(s) flag2] = pcgfun(W_sqrtZ_r(s), []);
  x = x_mu + x_cov;
  
  assert(flag1==0 && flag2==0, ...
         'PCG didn''t converge to the desired tolerance within the allotted number of iterations.')
  
end

% Sample from the posterior distribution p(\sigma|x,z,y,K)
% The variable names a, b, x, y, and k are used as described in the paper
function [s, s_mean] = sample_sigma_deblurring(x, y, k)
  % sigma^-2 is gamma-distributed with parameters a and b
  a = numel(y)/2 + 1;
  b = 2 ./ sum(sum((y-conv2(x,k,'valid')).^2));
  
  % draw a single sample and compute the mean of the density
  s = gamrnd(a, b).^(-1/2);
  s_mean = (a*b).^(-1/2);
  
  % make sure sigma isn't too close to 0
  s = max(1e-1,s);
end

% Matrix-vector multiplication expressed through convolutions
% Used to avoid building the full precision matrix Q
function y = Q_times(img, z, f, k, sigma, perm)
  if nargin < 6, perm = (1:numel(img))'; else, perm = perm(:); end
  img(perm) = img(:); % inverse permute image
  
  nfilters = numel(f);
  y = img(:) .* z{nfilters+1};
  
  for i = 1:nfilters
    tmp = conv2(img, f{i}, 'valid');
    tmp = conv2(tmp.*reshape(z{i}, size(tmp)), f{i}(end:-1:1,end:-1:1), 'full');
    y = y + tmp(:);
  end
  
  tmp = conv2(img, k/sigma, 'valid');
  tmp = conv2(tmp, k(end:-1:1,end:-1:1)/sigma, 'full');
  y = y + tmp(:);
  
  y = y(perm); % permute output
end

% Reduce number of non-zero entries in a blur kernel (sparsify)
% Input:    k: blur kernel k
%        keep: fraction of non-zero entries to keep (for keep < 1), otherwise number of non-zero entries to keep
%        show: boolean variable that toggles display of cut-off effect
% Output: truncated kernel f
function f = cut_off(k, keep, show)
  [desc, desc_idx] = sort(k(:),'descend');
  if keep < 1, keep = max(1,round(keep*nnz(k))); end
  
  f = zeros(size(k));
  f(desc_idx(1:keep)) = desc(1:keep);
  
  if nargin >= 3 && show
    figure(1), clf
    subplot(221), imagesc(k), axis image on, colorbar, title 'input'
    subplot(222), spy(k)
    subplot(223), imagesc(y), axis image on, colorbar, title 'output'
    subplot(224), spy(y)
    drawnow
  end
end

%%===========================================     Miscellaneous helper functions

function pcomp_found = parallel_computing_available
  pcomp_found = false;
  if exist('parfor') ~= 5 || exist('matlabpool') ~= 2, return; end
  v = ver;
  for i = 1:length(v)
    if strcmp(v(i).Name,'Parallel Computing Toolbox'), pcomp_found = true; break; end
  end
end

function plot_images(fh, x_gt, sigma_gt, y, k, x, sigma_est)
  ims = @(I) imshow(uint8(I), 'InitialMagnification', 'fit');
  figure(fh)
  subplot(1,4,1), ims(x_gt), title 'Original'
  subplot(1,4,3), ims(y), title({sprintf('Blurred (\\sigma_{GT} = %.2f)', sigma_gt), ...
                                 sprintf('PSNR = %.2fdB, SSIM = %.3f', ...
                                 pml.image_proc.psnr(x_gt, y), pml.image_proc.ssim_index(x_gt, y))});
  subplot(1,4,4), ims(x), title({sprintf('Deblurred (\\sigma_{est} = %.2f)', sigma_est), ...
                                 sprintf('PSNR = %.2fdB, SSIM = %.3f', ...
                                 pml.image_proc.psnr(x_gt, x), pml.image_proc.ssim_index(x_gt, x))});
  subplot(1,4,2), imagesc(k), axis image off, title('Blur kernel')
end

function plot_progress(fh, do_noise_est, rb, s, s_mu, c, psnrs, ssims, mapd, time, cpu_time)
  figure(fh)
  if do_noise_est
    if rb, sigma_progress = s_mu(:,1:c); else, sigma_progress = s(:,1:c); end
    sigma_progress = bsxfun(@rdivide, cumsum(sigma_progress,2), 1:c);
    subplot(5,1,1), plot(1:c, sigma_progress', 1:c, mean(sigma_progress)', '--k'), ylabel '\sigma_{est}'
  else
    subplot(5,1,1), plot(1:c, repmat(sigma,1,c)), ylabel '\sigma_{est}'
  end
  subplot(5,1,2), plot(1:c, psnrs(:,1:c)'), ylabel 'PSNR'
  subplot(5,1,3), plot(1:c, ssims(:,1:c)'), ylabel 'SSIM'
  subplot(5,1,4), plot(1:c, mapd(:,1:c)', 1:c, mean(mapd(:,1:c))', '--k'),  ylabel 'MAPD'
  subplot(5,1,5), plot(time(1:c), psnrs(end,1:c), cpu_time(1:c), psnrs(end,1:c))
  xlabel 'Time (seconds)', ylabel 'PSNR'
  legend 'Time' 'CPU time' 'location' 'southeast'
end

%%=============     Convert MRF object to struct (required only for parfor loop)

function s = mrf2struct(mrf)
  s = struct;
  s.imdims = mrf.imdims;
  s.experts = mrf.experts;
  s.epsilon = mrf.epsilon;
  s.conv2 = @(img, f) conv2(img, f, 'valid');
  s.filter_matrices = mrf.filter_matrices;
  s.filter = mrf.filter;
  s.nfilters = mrf.nfilters;
  s.nexperts = mrf.nexperts;
  s.sample_z = @(x) sample_z(s,x);
  s.energy = @(x) energy(s,x);
end

function z = sample_z(this, x)
  z = cell(1, this.nfilters);
  for i = 1:this.nfilters
    d_filter = this.conv2(reshape(x, this.imdims), this.filter{i});
    expert = this.experts{min(i,this.nexperts)};
    pz = expert.z_distribution(d_filter(:)');
    z{i} = this.experts{min(i,this.nexperts)}.scales(sample_discrete(pz));
  end
end

function L = energy(this, x)
  img = reshape(x, this.imdims);
  L = 0.5 * this.epsilon * sum(x.^2);
  for i = 1:this.nfilters
    d_filter = this.conv2(img, this.filter{i});
    L = L + sum(this.experts{min(i,this.nexperts)}.energy(d_filter(:)'));
  end
end

% draw a single sample from each discrete distribution (normalized weights in columns)
% domain start & stride is assumed to be 1
function xs = sample_discrete(pmfs)
  [nweights, ndists] = size(pmfs);
  % create cdfs
  cdfs = cumsum(pmfs, 1);
  % uniform sample for each distribution
  ys = rand(1, ndists);
  % subtract uniform sample and set 1s where difference >= 0
  inds = bsxfun(@minus, cdfs, ys) >= 0;
  % multiply each column with weight indices
  inds = bsxfun(@times, inds, (1:nweights)');
  % set 0s to NaN
  inds(inds == 0) = NaN;
  % min. weight index > 0 (NaNs are ignored by 'min')
  xs = min(inds, [], 1);
end

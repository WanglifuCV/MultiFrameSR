%% DEMO_DEBLURRING - Demonstrate MMSE-based non-blind deblurring with integrated noise estimation
% 
%  Author:  Uwe Schmidt, Department of Computer Science, TU Darmstadt
%  Contact: uwe.schmidt@gris.tu-darmstadt.de

% Copyright 2011 TU Darmstadt, Darmstadt, Germany.
% $Id: demo_deblurring.m 248 2011-05-30 16:10:51Z uschmidt $

function demo_deblurring
  [prev_dir, base_dir] = adjust_path;
  
  fprintf('Demo of non-blind deblurring with integrated noise estimation.\n')
  choice = input('(1) for pairwise MRF, or (2) for 3x3 FoE with 8 filters: ');
  if choice == 1, mrf = learned_models.cvpr_pw_mrf;  fprintf('Using pairwise MRF\n'); else
                  mrf = learned_models.cvpr_3x3_foe; fprintf('Using 3x3 FoE\n'); end
  
  sigma = 2.55; % choose noise std
  img_names = {'barbara.png', 'boat.png', 'fingerprint.png', 'house.png', 'lena.png', 'peppers256.png'};
  idx = 5; % choose index of img_names
  img_clean = double(imread(sprintf('images/%s', img_names{idx})));
  sc = 1/8; % choose scale (1 => original size)
  img_clean = imresize(img_clean, sc);
  
  load('blurkernel-levinetal.mat'); % load blur_kernel cell array
  bkidx = 3; k = blur_kernel{bkidx}; % choose blur kernel
  img_blurred = conv2(img_clean, k, 'valid'); % blur image
  img_blurred = img_blurred + sigma * randn(size(img_blurred)); % add noise
  % keep only part of the ground truth image (same size as blurred image)
  b = (size(k,1)-1)/2; img_clean = img_clean(b+1:end-b, b+1:end-b);
  
  % non-blind deblurring with noise estimation
  [img_deblurred, sigma_est] = deblur_mmse(mrf, img_blurred, k, img_clean, sigma, [], true, true, true);
  
  adjust_path(prev_dir, base_dir);
end

function [prev_dir, base_dir] = adjust_path(prev_dir, base_dir)
  if nargin == 2
    % restore working directory
    % restoring the path sometimes confuses MATLAB when running the code again ("clear classes" helps)
    cd(prev_dir); % rmpath(base_dir); 
    warning('on','MATLAB:mir_warning_maybe_uninitialized_temporary')
  else
    % save working directory and go to correct directory
    prev_dir = pwd; file_dir = fileparts(mfilename('fullpath')); cd(file_dir);
    last = @(v) v(end); base_dir = file_dir(1:last(strfind(file_dir, filesep))-1);
    % add base directory to path
    addpath(base_dir);
    warning('off','MATLAB:mir_warning_maybe_uninitialized_temporary')
  end
end
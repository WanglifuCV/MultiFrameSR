% The code in this package demonstrates image deblurring (and denoising) with integrated noise estimation as described in the CVPR'11 paper:
%                                                                                                                                                                   
%  Uwe Schmidt, Kevin Schelten, Stefan Roth.
%  Bayesian Deblurring with Integrated Noise Estimation.
%  IEEE Conference on Computer Vision and Pattern Recognition (CVPR'11), Colorado Springs, Colorado, June 2011.
% 
% Please cite the paper if you are using this code in your work.
% 
% The models used here are generic MRF image priors, as learned and described in the CVPR'10 paper:
% 
%  Uwe Schmidt, Qi Gao, Stefan Roth.
%  A Generative Perspective on MRFs in Low-Level Vision.
%  IEEE Conference on Computer Vision and Pattern Recognition (CVPR'10), San Francisco, USA, June 2010.
% 
% 
% Contents of restoration:
% 
%   demo_denoising                 - Demonstrate MMSE-based blind denoising with integrated noise estimation
%   demo_deblurring                - Demonstrate MMSE-based non-blind deblurring with integrated noise estimation
%   deblur_mmse                    - Image deblurring (and denoising) by approximating the MMSE estimate with samples
% 
% Contents of +learned_models:
% 
%   cvpr_3x3_foe                   - A learned 3x3 FoE as described in the CVPR'10 paper
%   cvpr_pw_mrf                    - A learned pairwise MRF as described in the CVPR'10 paper
% 
% Contents of +pml:
% 
%   Core implementation of our models and auxiliary functions

% Copyright 2011 TU Darmstadt, Darmstadt, Germany.
% $Id: Contents.m 249 2011-05-31 14:55:08Z uschmidt $
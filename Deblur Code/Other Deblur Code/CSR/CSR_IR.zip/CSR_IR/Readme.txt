Author: 

Weisheng Dong
School of Electronic Engineering, 
Xidian University, Xi'an, China.   


The code is associated with the following paper:

Weisheng Dong, Lei Zhang, and Guangming Shi,
"Centralized sparse representation for image restoration",
in IEEE Int. Conf. on Computer Vision, 2011. 

Please cite this paper if you use this code. 

For further information, please contact: wsdong@mail.xidian.edu.cn